package test;

public class Sparrow extends Bird implements Fly{
	public   void flying(){
		System.out.println("��ȸ���");
	}
}
