package test;

public class Eagle extends Bird implements Fly{
	public   void flying(){
		System.out.println("��ӥ���");
	}
}
