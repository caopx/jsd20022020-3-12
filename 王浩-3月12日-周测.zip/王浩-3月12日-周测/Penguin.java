package test;

public class Penguin extends Bird implements Swim{
	public   void swimming(){
		System.out.println("������Ӿ");
	}
}