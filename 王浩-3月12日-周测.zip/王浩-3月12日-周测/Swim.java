package test;

public interface Swim {
	  void swimming();
		
	
}
