package test;

public interface Fly {
	  void flying();
}