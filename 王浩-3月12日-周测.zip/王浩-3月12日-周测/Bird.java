package test;

public class Bird {
	public void  layegg(){
		System.out.println("����µ�");
	}
}
