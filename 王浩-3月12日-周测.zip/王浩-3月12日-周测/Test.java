package test;


public class Test {

	public static void main(String[] args) {
		 Bird[] b = new Bird[5];
		 b[0]= new Penguin();
		 b[1]= new Penguin();
		 b[2]= new Sparrow();
		 b[3]= new Sparrow();
		 b[4]= new Eagle();
		  for(int i=0;i<b.length;i++){
			if(i<2){
				Swim b1 = new Penguin();
				b1.swimming();
			}else if(i<4){
				Fly b2 = new Sparrow();
				b2.flying();
			}else{
				Fly b3 = new Eagle();
				b3.flying();
			}
				
			
		 }
	}

}
