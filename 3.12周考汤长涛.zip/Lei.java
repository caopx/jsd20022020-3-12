package oo.day10;

class Lei {
	public static void main(String[] args) {
		Bird[] bird = new Bird[5];
		bird[0] = new Penguin();
		bird[1] = new Penguin();
		bird[2] = new Sparrow();
		bird[3] = new Sparrow();
		bird[4] = new Eagle(); 
		for(int i=0;i<bird.length;i++) {
			if(i < 2) {
				((Swim) bird[i]).swimming();
			}else {
				((Fly) bird[i]).flying();
			}
		}
		}
}

// �ɽӿ�Fly
interface Fly {
	void flying();
}

// ��
class Bird {
	public void layegg() {
		System.out.println("����µ�");
	}

}

// ��Ӿ�ӿ�
interface Swim {
	void swimming();

}

// ���
class Penguin extends Bird implements Swim {
	public void swimming() {
		System.out.println("������Ӿ");
	}

}

// ��ȸ
class Sparrow extends Bird implements Fly {
	public void flying() {
		System.out.println("��ȸ���");
	}
}

// ��ӥ
class Eagle extends Bird implements Fly {
	public void flying() {
		System.out.println("��ӥ���");
	}
}
