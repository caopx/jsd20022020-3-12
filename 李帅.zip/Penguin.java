package test04;

public class Penguin extends Brid implements Swim{

	
	public void swimming() {
		System.out.println("������Ӿ");
		
	}
	
}
