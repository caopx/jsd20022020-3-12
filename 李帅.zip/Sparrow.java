package test04;

public class Sparrow extends Brid implements Fly {
	public void flying() {
		
	}
	public void show() {
		System.out.println("��ȸ���");
	}
}
