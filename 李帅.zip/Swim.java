package test04;

public interface Swim {
	abstract void swimming();

}
