package test04;

public class Brid {
	public void layegg() {
		
	}
	public void show() {
		System.out.println("����µ�");
	}
}
