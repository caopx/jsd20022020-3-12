package test04;

public interface Fly {
	abstract void flying();
}
