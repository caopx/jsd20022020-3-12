package test04;

public class Eagle extends Brid implements Fly{
public void flying() {
	
}
public void show() {
	System.out.println("��ӥ���");
}

}
