package test04;

public class Test {

	public static void main(String[] args) {
		Brid[] brids=new Brid[5];
		brids[0]=new Brid();
		brids[1]=new Brid();
		brids[2]=new Sparrow();
		brids[3]=new Sparrow();
		brids[4]=new Eagle();
	for (int i = 0; i < brids.length; i++) {
		    Brid b=brids[i];
		    b.show();
		}	
	}

}
