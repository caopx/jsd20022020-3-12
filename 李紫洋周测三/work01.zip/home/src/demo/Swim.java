package demo;

public interface Swim {

	public void swimming();
}
