package demo;

public interface Fly {
	
	public void flying();
}
