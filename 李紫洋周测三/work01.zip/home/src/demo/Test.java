package demo;

public class Test {

	private static final Bird Penguin = null;
	private static final Bird Sparrow = null;
	private static final Bird Eagle = null;

	public static void main(String[] args) {
		Bird[] bir = new Bird[5];
		bir[0]= (Penguin); 
		bir[1]= (Penguin); 
		bir[2]= (Sparrow); 
		bir[3]= (Sparrow); 
		bir[4]= (Eagle); 
		for (int i = 0; i < bir.length; i++) {
			if (i<=1) {
				Swim s = new Penguin();
				s.swimming();
			}else if(i<=3) {
				Fly fly = new Sparrow();
				fly.flying();
			}else {
				Fly fly = new Eagle();
				fly.flying();
			}
		}
		

	}

}
